<?php

namespace OXI_IMAGE_HOVER_PLUGINS\Modules\Carousel\Admin;

/**
 * Description of Effects1
 *
 * @author biplob
 */
use OXI_IMAGE_HOVER_PLUGINS\Modules\Carousel\Modules as Modules;
use OXI_IMAGE_HOVER_PLUGINS\Classes\Controls as Controls;

class Effects1 extends Modules {
    
}

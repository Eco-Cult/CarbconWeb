<?php

if (class_exists('ParagonIE_Sodium_Core32_Util', false)) {
    return;
}

/**
 * Class ParagonIE_Sodium_Core_Util
 */
abstract class ParagonIE_Sodium_Core32_Util extends ParagonIE_Sodium_Core_Util
{

}
